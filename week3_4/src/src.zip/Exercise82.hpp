#ifndef SUBMISSION_EXERCISE82_HPP_
#define SUBMISSION_EXERCISE82_HPP_

#include <math.h>

template<typename T>
T CalcAbs(T val) {
	T result;
	result = fabs(val);
	return result;
}


#endif /* SUBMISSION_EXERCISE82_HPP_ */
